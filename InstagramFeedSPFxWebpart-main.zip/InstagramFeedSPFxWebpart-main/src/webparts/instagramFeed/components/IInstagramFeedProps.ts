export interface IInstagramFeedProps {
  userToken: string;
  showIcon: Boolean;
  userFullName: string;
  accountName: string;
  layoutOneThirdRight: Boolean;
}
