# Instagram Feed in SPFx Web Part

## Summary

You can show Instagram posts in sharepoint webpart using swiper slider. To do this, you first need to create a token. Please click to read my medium article about it.

## Minimal Path to Awesome

- Clone this repository
- Ensure that you are at the solution folder
- in the command-line run:
  - **npm install**
  - **gulp serve**
