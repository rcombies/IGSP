export interface IError {
  status: number;
  heading: string;
  message: string;
}
