/* tslint:disable */
require("./InstagramFeed.module.css");
const styles = {
  app: 'app_42733b1b',
  swiper: 'swiper_42733b1b',
  'swiper-slide': 'swiper-slide_42733b1b',
  instagramFeed: 'instagramFeed_42733b1b',
  container: 'container_42733b1b',
  row: 'row_42733b1b',
  column: 'column_42733b1b',
  'ms-Grid': 'ms-Grid_42733b1b',
  title: 'title_42733b1b',
  subTitle: 'subTitle_42733b1b',
  description: 'description_42733b1b',
  button: 'button_42733b1b',
  label: 'label_42733b1b'
};

export default styles;
/* tslint:enable */